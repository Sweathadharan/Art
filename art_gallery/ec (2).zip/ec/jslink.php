<?php

 /* ALL JS FILES */
    echo "<script src='js/jquery-3.2.1.min.js'></script>";
    echo "<script src='js/popper.min.js'></script>";
    echo "<script src='js/bootstrap.min.js'></script>";
    /* ALL PLUGINS */
    echo "<script src='js/jquery.superslides.min.js'></script>";
    echo "<script src='js/bootstrap-select.js'></script>";
    echo "<script src='js/inewsticker.js'></script>";
    echo "<script src='js/bootsnav.js.'></script>";
    echo "<script src='js/images-loded.min.js'></script>";
    echo "<script src='js/isotope.min.js'></script>";
    echo "<script src='js/owl.carousel.min.js'></script>";
    echo "<script src='js/baguetteBox.min.js'></script>";
    echo "<script src='js/form-validator.min.js'></script>";
    echo "<script src='js/contact-form-script.js'></script>";
    echo "<script src='js/custom.js'></script>";
	echo "<script src='js/jquery.nicescroll.min.js'></script>";
	echo "<script src='js/jquery-ui.js'></script>";
	
	?>