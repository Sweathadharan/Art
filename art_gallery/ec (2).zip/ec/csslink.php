<?php
/* Site Icons */
    /* Bootstrap CSS */
    echo "<link rel='stylesheet' href='css/bootstrap.min.css'>";
    /* Site CSS */
    echo"<link rel='stylesheet' href='css/style.css'>";
    /* Responsive CSS */
    echo"<link rel='stylesheet' href='css/responsive.css'>";
    /* Custom CSS */
    echo"<link rel='stylesheet' href='css/custom.css'>";
	echo "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>";
?>