<div class="categories-shop">
        <div class="container">
            <div class="row">
			<div class="col-lg-10">
                    <div class="title-all text-center">
                        <h1> <center>Tisane Suggestion</center></h1>
                        
                    </div>
                </div>
             <?php list_category();?>   
                
                
            </div>
        </div>
    </div>