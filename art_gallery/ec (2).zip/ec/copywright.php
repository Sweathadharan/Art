  <div class="footer-copyright">
        <p class="footer-company">All Rights Reserved. &copy; 2021 <a href="#">The Ace Teas</a> Design By :
            <a href="#">The Ace Teas Traders</a></p>
    </div>