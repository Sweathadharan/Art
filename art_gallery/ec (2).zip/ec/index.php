<?php 
session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>The Ace Teas</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel='shortcut icon' href='images/favicon.png' type='image/png'>
    <link rel='apple-touch-icon' href='images/apple-touch-icon.png'>
    <?php
	require("csslink.php");
	?>
    
    
</head>

<body>

   <?php
		$sessionuser=@$_SESSION['user_name'];
		if($sessionuser=="")
		{
		require("top.php");
		}
		else
		{
		require("afterlogin.php");
		}
	?>	
   	<?php require("menuheader.php");?>
	<?php require("menusearchbar.php");?>
	<?php require("mainslider.php");?>
	<br><br>
	<div class="title-all text-center">
                        <h1>We promise you,We Give you only the best..! </h1>
                        <p>The Ace Teas bring you the exotic varities of loose leaf tea from the historic tea destination of India.We are strongly positioned to serve the product and the product designs are mostly traditional. Showcasing some of the finest creations in product - from classic designs that reflect the cultural traditions to contemporary artistic product. <br>You can even get product customized according to specifications for those special occasions in life.</p>
                    </div>
	<?php require("categories.php");?>
	<?php require("catproducts.php");?>
	<?php require("instagramfeed.php");?>
	<?php require("mainfooter.php");?>
	<?php require("loginmodal.php");?>
	<?php require("copywright.php");?>
	
	 
    <?php
	require("jslink.php");
	?>
	
	
	
</body>

</html>