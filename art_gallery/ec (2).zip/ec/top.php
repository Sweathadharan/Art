<div class="main-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="text-slid-box">
                        
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                   
                   
                    <div class="our-link">
                        <ul>
                            <li><a href="account.php">Create Account</a></li>
                            
                            <li><a href="" data-toggle="modal" data-target="#login-modal">Login</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>