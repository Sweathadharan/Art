<?php
$servername="localhost";
$username="root";
$password="";
$db="art";

$con = mysqli_connect("$servername","$username","$password","$db");

?>